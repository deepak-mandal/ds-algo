#Setup files.
from setuptools import setup
setup(name='myfriends',
	version='1.0',
description='A package to calculate wexpenses when you hang-o',
url='#',
	auther='deepak',
auther_email='dkmiitg@gmail.com',
	license='MIT',
	packages=['myfriends'],
zip_safe=False)
